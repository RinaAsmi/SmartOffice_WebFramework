-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: localhost
-- Waktu pembuatan: 26 Apr 2025 pada 18.53
-- Versi server: 10.4.32-MariaDB
-- Versi PHP: 8.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `smartoffice`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `office`
--

CREATE TABLE `office` (
  `id` int(255) NOT NULL,
  `kategori` enum('Word','Excel','PowerPoint') NOT NULL,
  `judul` varchar(255) NOT NULL,
  `slug` varchar(255) NOT NULL,
  `subjudul` varchar(255) NOT NULL,
  `deskripsi` text NOT NULL,
  `gambar` varchar(255) NOT NULL,
  `video_url` varchar(255) NOT NULL,
  `tips` text NOT NULL,
  `created_at` date DEFAULT NULL,
  `updated_at` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data untuk tabel `office`
--

INSERT INTO `office` (`id`, `kategori`, `judul`, `slug`, `subjudul`, `deskripsi`, `gambar`, `video_url`, `tips`, `created_at`, `updated_at`) VALUES
(1, 'Word', 'Pengenalan Word', 'pengenalan-word', 'Dasar-dasar menggunakan Word untuk pemula', 'Microsoft Word adalah aplikasi pengolah kata untuk membuat dokumen profesional seperti surat, laporan, dan lainnya.', 'word.png', 'VckqV2wC1gs?si=thzZJ4ji9PDPs8ND', 'Gunakan Ctrl + B untuk bold, Ctrl + S untuk menyimpan dokumen tersebut.', NULL, '2025-04-26'),
(2, 'Excel', 'Rumus Otomatis Excel', 'rumus-otomatis-excel', 'Belajar menggunakan rumus seperti SUM dan AVERAGE di Excel', 'Excel memungkinkan pengguna untuk menghitung dan menganalisis data secara otomatis dengan rumus-rumus sederhana maupun kompleks.', 'excel.png', 'Nt3YH68npW4?si=Z0yh7dea5eYFBbGS', 'Gunakan =SUM(A1:A5) untuk menjumlahkan nilai di Excel dengan cepat dan tepat.', NULL, '2025-04-26'),
(5, 'Word', 'Cara Menggunakan Microsoft Word dengan Efektif', 'cara-menggunakan-microsoft-word-dengan-efektif', 'Cara Menggunakan Microsoft Word dengan Efektif Pastinya', 'Materi ini membahas tentang cara-cara dasar dan lanjutan untuk menggunakan Microsoft Word dengan efektif dalam berbagai kebutuhan.', '1745672210_ec806ea3d5acade40585.jpg', 'dQw4w9WgXcQ', 'Gunakan shortcut keyboard untuk meningkatkan produktivitas!', '2025-04-26', '2025-04-26'),
(6, 'Word', 'Cara Membuat Surat Resmi', 'cara-membuat-surat-resmi', 'Surat Resmi Word', 'Panduan membuat surat resmi di Word.', '1745685619_ae91992b598bb6367a8b.jpeg', 'https://youtu.be/abcd1234', 'Gunakan template surat untuk konsistensi.', '2025-04-01', '2025-04-26'),
(7, 'Excel', 'Menghitung Rata-rata Otomatis di Excel', 'menghitung-rata-rata-otomatis-di-excel', 'Formula Rata-rata di Excel', 'Tutorial penggunaan formula AVERAGE.', '1745685529_2669f7069ea92f0d5588.jpg', 'https://youtu.be/efgh5678', 'Pastikan data yang dihitung bersih.', '2025-04-02', '2025-04-26'),
(8, 'PowerPoint', 'Tips Membuat Presentasi Memukau', 'tips-membuat-presentasi-memukau', 'Presentasi Keren PowerPoint', 'Trik visualisasi menarik untuk presentasi.', '1745685504_bf3119eb9449e9451312.png', 'https://youtu.be/ijkl9101', 'Gunakan gambar HD dan sedikit teks.', '2025-04-03', '2025-04-26'),
(9, 'Word', 'Membuat Daftar Isi Otomatis', 'membuat-daftar-isi-otomatis', 'Daftar Isi Word Otomatis', 'Cara cepat membuat daftar isi otomatis.', '1745685878_7260e9d0a9618405cbf3.jpeg', 'mnop1122', 'Gunakan Heading Style secara konsisten.', '2025-04-04', '2025-04-26'),
(10, 'Excel', 'Membuat Grafik Penjualan', 'membuat-grafik-penjualan', 'Grafik Penjualan di Excel', 'Membuat grafik penjualan dari tabel data.', '1745685844_c83b239f6990a387449e.jpeg', 'qrst3344', 'Pilih jenis grafik sesuai kebutuhan data.', '2025-04-05', '2025-04-26');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `office`
--
ALTER TABLE `office`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `office`
--
ALTER TABLE `office`
  MODIFY `id` int(255) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
